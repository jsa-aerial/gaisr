require 'rubygems'
require 'sinatra'

get '/slides' do
   
 File.read(File.join('public','slides.html'))
    
end

get '/jstest' do

   File.read(File.join('public','jstest.html'))

end
   