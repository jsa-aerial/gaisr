      // Content section used alot
      var content = document.getElementById('content');
      if (!window.FileReader) {
        content.innerHTML = "<p>This browser doesnt support the File API</p>";
      } else {
        // Page Layout
        content.innerHTML =
          '<p>Pick a file below or drag one into this area <br> <input type="file" id="file" /></p>' +
          '<p><b>Name:</b> <span id="name"></span><br>' +
          '<b>File Size:</b> <span id="size"></span><br>' +
          '<b>Content:</b> <br><br> <span id="file-content"></span>' +
          '</p>';
      
        // Prints out file properties.
        function displayFile(file) {
          document.getElementById('name').textContent = file.fileName;
          document.getElementById('size').textContent = file.fileSize;
          
      
          var reader = new FileReader();
      
          reader.onload = function(event) {
            document.getElementById('file-content').innerHTML = 
              event.target.result.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n|\r/g, '<br>');
          };
      
          reader.onerror = function() {
            document.getElementById('file-content').innerHTML = 'Unable to read ' + file.fileName;
          };
      
          reader.readAsText(file);
      
        }

		function drawChart(args) {
			var theChart = args[0];
			var time = new Date();
			var i = args[1];
			theChart.canvas.clearRect(0,0, 1100, 900);
//			theChart.scale.min = 4000 - i;
//			theChart.scale.max = 6000 + i;
		
			theChart.draw();
			
		//	times.push(time.getTime());
		}

        // Displays gene charts.
        function displayChart(file) {
          document.getElementById('name').textContent = file.fileName;
          document.getElementById('size').textContent = file.fileSize;
          
      
          var reader = new FileReader();
      
          reader.onload = function(event) {
				var canvas = document.getElementById('canvas');
				chart = new BChart(canvas, 900);
				chart.loadGenbank(event.target.result);

				chart.draw();		

				var startMin = 0;
				var startMax = chart.scale.max;
				
				var endMin = 165000;
				var endMax = 210000;
				
				var currPixels = startMax / chart.width;
				var newChart = undefined;
				var timeout;
				for ( var k=0; k < 115; k ++) {

					if (newChart == undefined)
						newChart = chart;
					else
						newChart = newChart.slice(newChart.scale.min + currPixels/2, newChart.scale.max - currPixels/2);
						
					newChart.scale.min = Math.round(startMin + currPixels/2);
					newChart.scale.max = Math.round(startMax - currPixels/2);

					newChart.scale.off = true;
					newChart.scale.max_min.auto = false;
					setTimeout(drawChart, 2000 + 5*k, [newChart, k] );
					timeout = 2000 + 5*k;
					startMax = newChart.scale.max;
					startMin = newChart.scale.min;
					currPixels = (newChart.scale.max - newChart.scale.min) * .02;
					
					// check if at max
				}
			
				newChart.scale.off = false;
				newChart.scale.offset = false;
				setTimeout(drawChart, timeout, [newChart, k]);
				
// 				for ( var k=400; k < 450; k ++) {
// 
// 					newChart = chart.slice(0 + k*100, 300000 - k*100);
// 					newChart.scale.min = 0 + k*100;
// 					newChart.scale.max = 300000 - k*100;
// //					newChart.scale.pretty = false;
// 					setTimeout(drawChart, 10*(k-400), [newChart, k] );
// 				}
				

				
	
            // document.getElementById('file-content').innerHTML = 
            //   event.target.result.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n|\r/g, '<br>');
          };
      
          reader.onerror = function() {
            document.getElementById('file-content').innerHTML = 'Unable to read ' + file.fileName;
          };
      
          reader.readAsText(file);
      
        }		 
      
        // Input handler
        document.getElementById('file').onchange = function() {
          displayFile(this.files[0]);
        };
      
        // Reduce movement by adding invisible border
        content.style.border = '4px solid transparent';
      
        // Add dragging events
        content.ondragenter = function() {
          content.style.border = '4px solid #b1ecb3';
          return false;
        };
      
        content.ondragover = function() {
          return false;
        };
      
        content.ondragleave = function() {
          return false;
        };
      
        content.ondrop = function(event) {
          content.style.border = '4px solid transparent';
          displayChart(event.dataTransfer.files[0]);
          return false;
        };
      }